                .PROJECT ASCIITAB

                .PROJECT ASCIITAB

                .PROJECT ASCIITAB
                .TAPE microsha-rkm      ; MICROSHA TAPE FORMAT
;*******************************************************************************
; THIS IS A CODE FOR AN ASCII CHARACTER TABLE DISPLAY PROGRAM RUNNING ON A 
; SOVIET-ERA COMPUTER SYSTEM "RADIO-86RK".
;
; WHAT THE PROGRAM DOES:
; 1. INITIALIZATION: CLEARS SCREEN AND DISPLAYS WELCOME MESSAGE
; 2. TABLE DISPLAY: SHOWS ASCII CHARACTERS 00-7F IN HEXADECIMAL FORMAT
; 3. FORMATTING: DISPLAYS 8 CHARACTERS PER LINE WITH PROPER SPACING
; 4. CONTROL HANDLING: SHOWS SPACES INSTEAD OF UNPRINTABLE CONTROL CHARACTERS
; 5. EXIT: CLEARS SCREEN AND RETURNS TO SYSTEM MONITOR
;
; KEY COMPONENTS:
; SYSTEM CALLS (ROM ROUTINES):
;   PUTCHAR (0F809H): OUTPUT CHARACTER (CHAR IN REGISTER C)
;   PUTHEX  (0F815H): OUTPUT HEXADECIMAL VALUE (VALUE IN REGISTER A)
;   PUTLINE (0F803H): GETCHAR
;   RETURN  (0F89DH): RETURN TO SYSTEM MONITOR
;
; DISPLAY LOGIC:
;   - EACH LINE SHOWS 8 CHARACTERS IN FORMAT: [ HEX CHAR HEX CHAR ... ]
;   - CONTROL CHARACTERS (00-1F, 7F) ARE DISPLAYED AS SPACES
;   - PRINTABLE CHARACTERS (20-7E) ARE DISPLAYED NORMALLY
;   - PROPER SPACING MAINTAINED BETWEEN CODES AND CHARACTERS
;
;*******************************************************************************                
                ORG     1C00H           

GETCHAR         EQU     0F803H           ; WAIT AND GET CHAR TO A
PUTCHAR         EQU     0F809H           ; PUT CHAR IN C
PUTHEX          EQU     0F815H           ; PUT HEX IN A
PUTLINE         EQU     0F818H           ; PUT STRING IN HL
RETURN          EQU     0F89DH           ; QUIT TO MONITOR

CHARZERO        EQU     00H
CHARBELL        EQU     07H
CHARBS          EQU     08H
CHARLF          EQU     0AH
CHARHOME	EQU	0CH
CHARCR          EQU     0DH        
CHARRIGHT	EQU	18H
CHARUP		EQU	19H
CHARDOWN	EQU	1AH
CHARAR2		EQU	1BH
CHARCLS         EQU     1FH
CHARSPC         EQU     20H
CHARQUEST       EQU     3FH

                MVI     C,1FH
                CALL    PUTCHAR
                MVI     C,CHARCR
                CALL    PUTCHAR
                MVI     B,00H             ; B = счетчик символов (00-7F)
                MVI     D,00H             ; D = счетчик символов в строке (0-7)
LOOP:           MVI     C,CHARSPC ; Вывод пробела перед кодом
                CALL    PUTCHAR
                MOV     A,B      ; Вывод шестнадцатеричного кода символа
                CALL    PUTHEX
                MVI     C,CHARSPC  ; Вывод пробела после кода
                CALL    PUTCHAR
                ; Проверка на управляющие символы (объединена в одну таблицу)
                MOV     A,B
                CPI     CHARBELL
                JZ      SKIP
                CPI     CHARBS
                JZ      SKIP
                CPI     CHARLF
                JZ      SKIP
                CPI     CHARHOME
                JZ      SKIP
                CPI     CHARCR
                JZ      SKIP
                CPI     CHARRIGHT
                JZ      SKIP
                CPI     CHARUP
                JZ      SKIP
                CPI     CHARDOWN
                JZ      SKIP
                CPI     CHARAR2
                JZ      SKIP
                CPI     CHARCLS
                JZ      SKIP
                MOV     C,A     ; Вывод символа, если это не управляющий символ
                CALL    PUTCHAR
                MVI     C,CHARSPC    ; Вывод пробела после символа
                CALL    PUTCHAR
                JMP     NEXT               ; Переход к следующей итерации
SKIP:    ; Пропуск вывода символа для управляющих кодов
                MVI     C,CHARSPC           ; Два пробела вместо символа
                CALL    PUTCHAR
                MVI     C,CHARSPC
                CALL    PUTCHAR
NEXT:    ; Переход к следующему символу
                INR     D                  ; Увеличиваем счетчик в строке
                MOV     A,D
                CPI     08H                ; Проверяем, достигли ли 8 символов
                JNZ     CONTINUE           ; Если нет, продолжаем
                MVI     C,CHARLF ; Выводим перевод строки
                CALL    PUTCHAR
                MVI     C,CHARCR
                CALL    PUTCHAR
                MVI     D,00H            ; Сбрасываем счетчик строки
CONTINUE:       INR     B
                MOV     A,B
                CPI     80H             ; До символа 7Fh включительно
                JNZ     LOOP               ; Продолжаем цикл
EXIT:    ; Завершение программы
                CALL    GETCHAR
                JMP     RETURN            ; Возврат в монитор
