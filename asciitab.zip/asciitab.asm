    ; 🐟 для Микроши
    .project asciitab
    .tape microsha-rkm ; формат ленты RKM
; Оптимизированная программа вывода таблицы символов (00-7F) на Радио-86РК
; Вывод по 8 символов в строке
        ORG  1C00h
        ; Инициализация: вывод управляющего символа и переход на новую строку
        MVI  C,  1FH
        CALL 0F809H
        MVI  C,  0DH
        CALL 0F809H
        MVI  B,  00H             ; B = счетчик символов (00-7F)
        MVI  D,  00H             ; D = счетчик символов в строке (0-7)
LOOP:    ; Вывод пробела перед кодом
        MVI  C,  ' '
        CALL 0F809H
        ; Вывод шестнадцатеричного кода символа
        MOV  A,  B
        CALL 0F815H
        ; Вывод пробела после кода
        MVI  C,  ' '
        CALL 0F809H
        ; Проверка на управляющие символы (объединена в одну таблицу)
        MOV  A,  B
        CPI  07H                ; BEL
        JZ   SKIP
        CPI  08H                ; BS
        JZ   SKIP
        CPI  0AH                ; LF
        JZ   SKIP
        CPI  0CH                ; FF
        JZ   SKIP
        CPI  0DH                ; CR
        JZ   SKIP
        CPI  18H                ; CAN
        JZ   SKIP
        CPI  19H                ; EM
        JZ   SKIP
        CPI  1AH                ; SUB
        JZ   SKIP
        CPI  1BH                ; ESC
        JZ   SKIP
        CPI  1FH                ; US
        JZ   SKIP
        ; Вывод символа, если это не управляющий символ
        MOV  C,  A
        CALL 0F809H
        ; Вывод пробела после символа
        MVI  C,  ' '
        CALL 0F809H
        JMP  NEXT               ; Переход к следующей итерации
SKIP:    ; Пропуск вывода символа для управляющих кодов
        MVI  C,  ' '            ; Два пробела вместо символа
        CALL 0F809H
        MVI  C,  ' '
        CALL 0F809H
NEXT:    ; Переход к следующему символу
        INR  D                  ; Увеличиваем счетчик в строке
        MOV  A,  D
        CPI  08H                ; Проверяем, достигли ли 8 символов
        JNZ  CONTINUE           ; Если нет, продолжаем
        ; Выводим перевод строки
        MVI  C, 0AH
        CALL 0F809H
        MVI  C,  0DH
        CALL 0F809H
        MVI  D,  00H            ; Сбрасываем счетчик строки
CONTINUE:
        INR  B
        MOV  A,  B
        CPI  80H                ; До символа 7Fh включительно
        JNZ  LOOP               ; Продолжаем цикл
EXIT:    ; Завершение программы
        CALL 0F803H            ; Очистка экрана
        JMP  0F89Dh            ; Возврат в монитор
